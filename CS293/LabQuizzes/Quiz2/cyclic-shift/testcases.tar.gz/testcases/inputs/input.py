def gen_worst_case(n, f):
	x = n//f

	s = "a"*(x-1) + "b"

	print(s*f)

if __name__ == "__main__":
	comps = [4324320, 21621600, 367567200]

	n = int(input())

	if n == 14:
		print("a"*int(1e8))
	elif n == 15:
		gen_worst_case(comps[0], 2)
	elif n == 16:
		gen_worst_case(comps[1], 3)
	elif n == 17:
		gen_worst_case(comps[1], 2)
	elif n == 18:
		gen_worst_case(comps[2], 5)
	elif n == 19:
		gen_worst_case(comps[2], 3)
	else:
		gen_worst_case(comps[2], 2)